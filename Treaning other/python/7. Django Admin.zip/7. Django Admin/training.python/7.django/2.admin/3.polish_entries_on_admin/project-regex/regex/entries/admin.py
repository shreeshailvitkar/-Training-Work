from django.contrib import admin
from entries.models import Entry


@admin.register(Entry)
class EntryAdmin(admin.ModelAdmin):
    list_display = [
        'pattern',
        'test_string',
        'user'
    ]
    list_filter = ['user']
    search_fields = ['test_string']
