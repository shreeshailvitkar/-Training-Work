from django.contrib import admin
from entries.models import (
    Entry,
    UserProfile,
)


@admin.register(Entry)
class EntryAdmin(admin.ModelAdmin):
    list_display = [
        'pattern',
        'test_string',
        'user'
    ]
    list_filter = ['user']
    search_fields = ['test_string']


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ['user', 'nickname']
    list_filter = ['nickname']
    search_fields = ['nickname']
