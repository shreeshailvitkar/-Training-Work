from django.contrib.auth.models import User
from django.db import models
from django.utils import timezone


class Entry(models.Model):
    date_added = models.DateTimeField(default=timezone.now)
    pattern = models.CharField(max_length=255)
    test_string = models.CharField(max_length=255)
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
    )

    class Meta:
        verbose_name_plural = 'entries'


class UserProfile(models.Model):
    nickname = models.CharField(max_length=255)
    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
    )
