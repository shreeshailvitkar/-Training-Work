import { Component } from '@angular/core';

import { Entry } from './entry';
import { EntriesService } from './entries.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  providers: [EntriesService],
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  entries: Entry[] = [];
  title = 'regex-portal';

  constructor(private entriesService: EntriesService) {}

  ngOnInit() {
    this.getEntries();
  }

  getEntries(): void {
    this.entriesService.getEntries()
      .subscribe(entries => (this.entries = entries));
  }
}
