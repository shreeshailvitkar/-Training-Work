export interface Entry {
  name: string;
  date_added: string,
  id: number,
  pattern: string,
  test_strings: Array<string>,
  user: string,
}
