import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';


import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Entry } from './entry';
import { HttpErrorHandler, HandleError } from './http-error-handler.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type':  'application/json',
    Authorization: 'Token 608da285e202324a79bc4b177e4c2b4fc68acf8f'
  })
};

@Injectable()
export class EntriesService {
  entriesUrl = 'http://localhost:8000/api/entries/';
  private handleError: HandleError;

  constructor(
    private http: HttpClient,
    httpErrorHandler: HttpErrorHandler) {
    this.handleError = httpErrorHandler.createHandleError('EntriesService');
  }

  getEntries(): Observable<Entry[]> {
    return this.http.get<Entry[]>(this.entriesUrl, httpOptions)
      .pipe(
        catchError(this.handleError('getEntries', []))
      );
  }
}
