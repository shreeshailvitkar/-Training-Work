from django.test import TestCase


class TryThisTests(TestCase):
    def test_try_this(self):
        self.assertEqual(1, 2)
